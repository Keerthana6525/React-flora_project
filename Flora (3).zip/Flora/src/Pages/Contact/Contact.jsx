import React from 'react';
import { Container, TextField, Button, Typography, Box, Paper } from '@mui/material';

const Contact = () => {
  return (
    <Box
      component="section"
      sx={{
        mb: 5,
        backgroundColor: '#bf90d2',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        backgroundRepeat: 'no-repeat',
        paddingTop: 8,
        paddingBottom: 8,
      }}
    >
      <Container maxWidth="sm">
        <Paper
          component="form"
          action="https://api.web3forms.com/submit"
          method="POST"
          sx={{
            padding: 3,
            marginTop: 5,
            boxShadow: 3,
            backgroundColor: 'rgba(255, 255, 255, 0.8)', // Semi-transparent background for form
          }}
        >
          <Typography variant="h4" component="h4" gutterBottom>
            Fillup The Form
          </Typography>
          <input type='hidden' name='access_key' value='1d2dcc2e-e3dc-4296-ab58-4bc7f21d00a9' />
          <Box display="flex" flexDirection="column" gap={2}>
            <TextField
              label="Enter Your Name"
              name="name"
              variant="outlined"
              required
              fullWidth
            />
            <TextField
              label="Enter Your Email"
              name="email"
              variant="outlined"
              required
              fullWidth
            />
            <TextField
              label="Message"
              name="message"
              variant="outlined"
              multiline
              rows={4}
              fullWidth
            />
            <input type='hidden' name='redirect' value='https://web3forms.com/success' />
            <Button variant="contained" color="primary" type="submit">
              Submit Request
            </Button>
          </Box>
        </Paper>
      </Container>
    </Box>
  );
}

export default Contact;

