import {Box , Container,styled, Typography} from "@mui/material";
import React from 'react';
import {Data} from '../../StaticData/Data'
import CustomCards from '../../Components/CustomCards/CustomCards'

const Galllery=() => {
    const FloralBox = styled(Box)(({theme})=>({
        display:'flex',
        justifyContent:'space-between',
        marginTop:theme.spacing(5),
        [theme.breakpoints.down("md")]:{
            flexDirection:'column',
            alignItems:'center',
        },
    }));
    const PropertiesTextBox= styled(Box)(({theme})=>({
        [theme.breakpoints.down("md")]:{
            textAlign:'center',
        },
    }));
  return (
    <Box sx={{mt:5, py :10}}>
        <Container>
            <PropertiesTextBox>
                <Typography sx={{color:'#000339', fontSize:'35px', fontWeight:'bold',ml:'13px'}}>
                    Featured Bouquets
                    </Typography>
                <Typography sx={{color:'#5A6473', fontSize:'16px',mt:1,ml:'13px'}}>
                    Explore varieties of Flora fragnence..!!!
                    </Typography>
            </PropertiesTextBox>
            <FloralBox>
                {Data.map((floralItem)=>(
                    <CustomCards
                        key={floralItem.id}
                        img={floralItem.img}
                        price={floralItem.price}
                        item={floralItem.item}
                        likes={floralItem.likes}
                        heart={floralItem.heart}
                        share={floralItem.share}
                    />
                ))};
            </FloralBox>
        </Container>
    </Box>
  )
};

export default Galllery;
