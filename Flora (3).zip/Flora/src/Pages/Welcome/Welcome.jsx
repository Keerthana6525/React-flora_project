import {Box ,  Typography } from "@mui/material";
import {styled} from "@mui/system";
import React from 'react';
import CustomButton from "../../Components/CustomButton/CustomButton";
import './Welcome.css'

const Welcome=() => {
    const CustomBox = styled(Box)(({theme}) => ({
        display:"flex",
        justifyContent:"center",
        gap:theme.spacing(5),
        marginTop:theme.spacing(3),
        [theme.breakpoints.down("md")]:{
            flexDirection:"column",
            alignItems:"center",
            textAlign:"center",
        },
    }));
    const Title = styled(Typography)(({theme}) => ({
        fontSize:"25 px",
        color:"#b58493",
        fontWeight: "bold",
        fontFamily:' Times new Roman',
        fontStyle:'italic',
        margin: theme.spacing(4, 0, 4, 0),
        [theme.breakpoints.down("sm")]: {
            fontSize: "40px",
        },
    }));
  return (
    <Box sx={{minHeight:'10vh'}}>
        <div className='Container'>
            <CustomBox>
                <Box sx={{ flex: "1", alignItems:'center' }}>
                    <Typography
                    variant="body2"
                    sx={{
                        fontSize:"18px",
                        color: "#687690",
                        fontWeight: "500",
                        mt :10,
                        mb :4,
                    }}>
                        
                    </Typography>
                    <Title variant="h2">
                        To share a flower, is <br/> to share the happiness.
                    </Title>
                    <br/>
                    <br/>
                    {/* <Typography 
                        variant="body2"
                        sx={{ fontSize:"18px", color: "#5A6473", my:4 }}
                    >
                        Here you will find the most perfect bouquest to <br/> Find your own happiness.Enjoy the Freshness,<br/> from our farm to your table.
                    </Typography> */}
                    <CustomButton
                        backgroundColor="#0F1B4C" 
                        color="#fff"
                        marginTop='10px'
                        buttonText="More About Us"
                        welcomeBtn={true}
                    />

                </Box>
                
            </CustomBox>
            

        </div>
    </Box>
  )
};

export default Welcome;
