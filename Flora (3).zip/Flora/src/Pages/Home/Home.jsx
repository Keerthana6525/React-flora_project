import React from 'react'
import Welcome from '../Welcome/Welcome'
import Booking from '../Booking/Booking'
import Partner from '../Partner/Partner'
import Galllery from '../Gallerry/Galllery'
import Delivery from '../Delivery/Delivery'
import About from '../AboutUs/About'


function Home() {
  return (
    <>
      <Welcome/>
      <Booking/>
      <Galllery/>
      <About/>      
      <Delivery/>
      <Partner/>
      
    </>
  )
}

export default Home
