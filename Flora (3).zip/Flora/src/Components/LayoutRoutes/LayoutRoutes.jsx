import React from 'react'
import { BrowserRouter as Router,Route,Routes } from 'react-router-dom'
import Headerr from '../Headers/Headerr'
import Footer from '../Footer/Footer'
import Home from '../../Pages/Home/Home'
import Booking from '../../Pages/Booking/Booking'
import Galllery from '../../Pages/Gallerry/Galllery'
import About from '../../Pages/AboutUs/About'
import Ntfound from '../../Pages/NotFound/Ntfound'
import Contact from '../../Pages/Contact/Contact'

function LayoutRoutes() {
  return (
    <Router>
        <Headerr/>
        <Routes>
           <Route path='/' element={<Home/>} /> 
           <Route path='/Gallerry' element={<Galllery/>} /> 
           <Route path='/Service' element={<Booking/>} /> 
           <Route path='/About' element={<About/>} /> 
           <Route path='/Contact' element={<Contact/>}/>
           <Route path='/*' element={<Ntfound/>} /> 
           
        </Routes>
        <Footer/>
    </Router>
  )
}

export default LayoutRoutes
