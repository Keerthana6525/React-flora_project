import React from 'react'
import LayoutRoutes from './Components/LayoutRoutes/LayoutRoutes';

function App() {
  return (
    <>
    
    <LayoutRoutes/>
    </>
    );
}

export default App
