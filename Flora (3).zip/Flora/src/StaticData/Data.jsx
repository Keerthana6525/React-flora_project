import Flower1 from "../Assets/flwr4.jpg"
import Flower2 from "../Assets/flwr3.jpg"
import Flower3 from "../Assets/flwr7.jpeg"
export const  Data = [
    {
        id: "1",
        img:Flower1,
        name:"Wedding Bouquet",
        price:"150",
        item:"Wedding Bouquet",
        likes: 287,
        heart: 223,
        share:2000,
    },
    {
        id: "2",
        img:Flower2,
        name:"Official Bouquet",
        price:"490",
        item:"Official Bouquet",
        likes: 312,
        heart: 222,
        share:2500,
    },
    {
        id: "3",
        img:Flower3,
        name:"Unique Bouquet",
        price:"250",
        item:"Unique Bouquet",
        likes: 88,
        heart: 53,
        share:2030,
    }
    
]